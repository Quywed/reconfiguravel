# Relatório Técnico: Detetor de Sequência (FSM Moore)

**Cadeira:** Computação Reconfigurável  
**Instituição:** Universidade do Algarve - Instituto Superior de Engenharia (UAlg ISE)  
**Ano Letivo:** 2025/2026

**Realizado por:**
* Lucas Machadinho Martins - a79294 - a79294@ualg.pt

---

Este projeto foi desenvolvido com o objetivo de desenhar, implementar e verificar uma Máquina de Estados Finitos (FSM) do tipo Moore capaz de detetar o padrão sequencial de 8 bits **`11011011`** num fluxo de dados série síncrono (`din`), garantindo o suporte a sequências sobrepostas (*overlapping sequences*).

---


## 1. Organização e Função de Cada Ficheiro

Para assegurar uma arquitetura modular, limpa e de fácil manutenção, o projeto está estruturado em três ficheiros fundamentais:

1. **`seq_detector.vhd` (Descrição de Hardware RTL):**
   * Contém a especificação formal da FSM Moore. 
   * Implementa a divisão rigorosa em **dois processos**: um síncrono (registo de estado com reset síncrono ativo em nível alto) e outro combinatório (cálculo do próximo estado e atribuição da saída `detect`).

2. **`seq_detector_tb.vhd` (Testbench Auto-Verificável Síncrono):**
   * Gera o sinal de relógio (`clk`) e o sinal de reposição síncrona (`rst`).
   * Injeta os estímulos de teste no porto `din`.
   * **Auto-verificação integrada:** Mantém um registo de deslocamento virtual síncrono que prevê se o padrão foi alcançado e compara-o dinamicamente com a saída real `detect` através de instruções `assert`. Caso ocorra uma divergência, a simulação é interrompida com um erro explícito.

3. **`sim.do` (Script de Automação TCL):**
   * Automatiza o fluxo completo no ModelSim Intel FPGA.
   * Cria a biblioteca `work`, compila os ficheiros VHDL na ordem correta, inicializa o simulador, adiciona os sinais à janela gráfica organizados por divisores e cores, e corre a simulação automaticamente.

---

## 2. Diagrama de Transição e Tabela de Estados

A FSM foi projetada com **9 estados** autónomos para rastrear o maior sufixo do fluxo de entrada que coincide com o prefixo do padrão-alvo `11011011`. 

A tabela abaixo descreve as transições de estado para cada entrada síncrona possível em `din`:

| Estado Atual | Prefixo Reconhecido | Próximo Estado se `din = '0'` | Próximo Estado se `din = '1'` | Saída `detect` |
| :--- | :---: | :---: | :---: | :---: |
| **S0** | Nenhum | S0 | S1 | 0 |
| **S1** | "1" | S0 | S2 | 0 |
| **S2** | "11" | S3 | S2 | 0 |
| **S3** | "110" | S0 | S4 | 0 |
| **S4** | "1101" | S0 | S5 | 0 |
| **S5** | "11011" | S6 | S2 | 0 |
| **S6** | "110110" | S0 | S7 | 0 |
| **S7** | "1101101" | S0 | **S8_MATCH** | 0 |
| **S8_MATCH** | **"11011011"** | **S6** *(Overlap)* | **S2** *(Overlap)* | **1** |

### Teoria da Resolução de Sobreposições (Overlap)
Quando o sistema atinge o estado de sucesso **`S8_MATCH`**, significa que os últimos 8 bits processados foram `11011011`. 
* **Se o bit seguinte for `0`:** A sequência total passa a ser `110110110`. O maior sufixo desta sequência que coincide com o prefixo do nosso padrão é `110110` (6 bits). Portanto, em vez de recomeçar do início, a máquina transita diretamente para o estado **`S6`**, poupando 6 ciclos de relógio.
* **Se o bit seguinte for `1`:** A sequência acumulada torna-se `110110111`. O maior sufixo útil que coincide com o prefixo é `11` (2 bits). Assim, a FSM transita de forma síncrona para o estado **`S2`**, poupando 2 ciclos de relógio.

---

## 3. Excertos do Código e Lógica de Implementação

### Registo de Estado Síncrono (`seq_detector.vhd`)
O bloco síncrono garante que todas as transições de estado e a avaliação do reset ativo em nível alto ocorram estritamente no flanco ascendente do relógio (`clk`).

```vhdl
process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            state <= S0; -- Reset síncrono obriga o retorno ao estado inicial
        else
            state <= next_state; -- Atualização segura de estado
        end if;
    end if;
end process;

```
#### Lógica de Saída e Transições

A saída da FSM é do tipo Moore, dependendo exclusivamente do estado atual state. A lógica de transição usa um bloco combinatório estruturado por uma instrução `case`:

```vhdl
process(state, din)
begin
    -- Atribuição da saída Moore (depende apenas do estado atual)
    if state = S8_MATCH then
        detect <= '1';
    else
        detect <= '0';
    end if;

    -- Lógica combinatória do próximo estado
    case state is
        when S0 =>
            if din = '1' then next_state <= S1; else next_state <= S0; end if;
        -- [... transições intermédias de S1 a S7 ...]
        when S8_MATCH =>
            -- Tratamento inteligente do Overlap síncrono
            if din = '0' then 
                next_state <= S6; 
            else 
                next_state <= S2; 
            end if;
        when others =>
            next_state <= S0;
    end case;
end process;
```

### Algoritmo de Auto-Verificação (`seq_detector_tb.vhd`)

O testbench gera os estímulos e compara continuamente a saída `detect` da unidade sob teste (UUT) com uma previsão lógica gerada por um registo de deslocamento virtual de 8 bits:

```vhdl
process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            state <= S0; -- Reset síncrono obriga o retorno ao estado inicial
        else
            state <= next_state; -- Atualização segura de estado
        end if;
    end if;
end process;

```

---

## 4. Análise Crítica das Waveforms (Simulação no ModelSim)
A forma de onda gerada síncronamente pela simulação demonstra o cumprimento de todos os requisitos de temporização e comportamento lógico.

#### A. Validação do Reset Síncrono
No início da simulação, o sinal de reset (``rst``) encontra-se ativo em nível alto (``1``). Podemos observar que o sinal ``state`` permanece estável em ``S0`` e o sinal ``detect`` fica a ``0``, mesmo com variações no sinal de entrada ``din``. A transição para o estado ``S1`` só ocorre no primeiro flanco de relógio ativo após a descida do sinal ``rst`` para ``0``.

![Alt text](pics_readme/pic_a.png)

#### B. Análise da Primeira Deteção (Match Limpo)

Após a libertação do ``reset``, o fluxo de dados injetado em ``din`` é ``11011011``.


**1.** A máquina progride de forma síncrona ciclo a ciclo: ``S0`` -> ``S1`` -> ``S2`` -> ``S3`` -> ``S4`` -> ``S5`` -> ``S6`` -> ``S7``.

![Alt text](pics_readme/pic_b1.png)

**2.** No ciclo seguinte, a FSM entra no estado de sucesso ``S8_MATCH``. O sinal de saída ``detect`` sobe para nível alto por exatamente um ciclo de relógio. Isto confirma a latência de 1 ciclo da FSM Moore, em que a saída reflete o estado no ciclo posterior à amostragem do último bit síncrono.

![Alt text](pics_readme/pic_b2.png)

#### C. Verificação de Overlap com Entrada ``0``

Logo após o primeiro match, a entrada série ``din`` envia um ``0`` síncrono.

- O estado transita diretamente para o estado ``S6`` (reaproveitando o padrão "110110"). Com as novas amostras síncronas de ``1`` e ``1``, a FSM rapidamente transita de ``S6`` -> ``S7`` -> ``S8_MATCH``.

- Observa-se a geração do segundo pulso de ``detect`` com uma periodicidade muito mais curta, validando o tratamento de sobreposição.


![Alt text](pics_readme/pic_c1.png)

#### D. Verificação de Overlap com Entrada ``1``

No final da simulação, é injetado um novo padrão que culmina em match. Logo a seguir, é mantido o sinal ``din`` a ``1`` síncrono.

A FSM transita de ``S8_MATCH`` diretamente para o estado ``S2`` (reaproveitando o prefixo "11").

Seguidamente, com a entrada de ``0`` (sinalizando a sequência 110), a máquina transita corretamente de ``S2`` -> ``S3`` -> ``S4``.

![Alt text](pics_readme/pic_d1.png)


Isto valida com sucesso a lógica de transição de overlap para sequências com excesso de uns consecutivos.

#### E. Verificação de Overlap com Entrada ``1``

Abaixo encontra-se a validação das asserções automáticas capturadas a partir do terminal (Transcript) do ModelSim, confirmando que o algoritmo correu até ao fim e exibiu a nota de sucesso, o que comprova a ausência de falhas lógicas ao longo de todo o tempo de simulação.

![Alt text](pics_readme/pic_e.png)

---

## 5. Instruções para Execução do Projeto no ModelSim
Para reproduzir esta simulação na sua máquina de forma totalmente automática:

1. Abra o **ModelSim Intel FPGA**.

2. No menu principal, vá a **File -> Change Directory...** e selecione a pasta que contém os ficheiros do projeto.

3. Na janela da consola **Transcript** (na parte inferior da interface), execute o comando de automação:

```
do sim.do
```

4. O script tratará de todas as compilações, configuração da visualização gráfica dos sinais e execução dos testes. A simulação terminará com uma mensagem de sucesso no terminal, provando que o circuito é síncrono e livre de erros.