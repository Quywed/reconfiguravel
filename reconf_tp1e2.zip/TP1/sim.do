# Apagar biblioteca de trabalho antiga se existir e criar uma nova
if [file exists work] { vdel -all -lib work }
vlib work

# Compilar os ficheiros VHDL na ordem correta
vcom -93 seq_detector.vhd
vcom -93 seq_detector_tb.vhd

# Iniciar a simula��o no Testbench
vsim -voptargs="+acc" work.seq_detector_tb

# Configurar a janela de Wave (Formas de Onda)
add wave -divider "Sinais de Controlo"
add wave -color "Yellow" /seq_detector_tb/clk
add wave -color "Red"    /seq_detector_tb/rst

add wave -divider "Fluxo de Dados"
add wave -color "Cyan"   /seq_detector_tb/din
add wave -color "Green"  /seq_detector_tb/detect

add wave -divider "Estado Interno da FSM"
add wave -color "Orange" /seq_detector_tb/uut/state

# Correr a simula��o por 800 ns
run 800 ns

# Ajustar o Zoom automaticamente na janela de Wave
wave zoom full