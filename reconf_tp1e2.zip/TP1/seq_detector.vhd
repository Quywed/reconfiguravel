library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity seq_detector is
    port (
        clk    : in  std_logic;
        rst    : in  std_logic;
        din    : in  std_logic;
        detect : out std_logic
    );
end entity;

architecture rtl of seq_detector is
    -- Defini��o dos estados para o padr�o 11011011
    type state_t is (S0, S1, S2, S3, S4, S5, S6, S7, S8_MATCH);
    signal state, next_state : state_t;
begin

    -- 1. Processo S�ncrono: Registo de Estado com Reset S�ncrono
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                state <= S0;
            else
                state <= next_state;
            end if;
        end if;
    end process;

    -- 2. Processo Combinat�rio: L�gica do Pr�ximo Estado e Sa�da (Moore)
    process(state, din)
    begin
        -- Valor por defeito da sa�da (Moore: depende apenas do estado atual)
        if state = S8_MATCH then
            detect <= '1';
        else
            detect <= '0';
        end if;

        -- L�gica de transi��o de estados
        case state is
            when S0 => -- Nenhum bit v�lido
                if din = '1' then next_state <= S1; else next_state <= S0; end if;
                
            when S1 => -- "1"
                if din = '1' then next_state <= S2; else next_state <= S0; end if;
                
            when S2 => -- "11"
                if din = '0' then next_state <= S3; else next_state <= S2; end if;
                
            when S3 => -- "110"
                if din = '1' then next_state <= S4; else next_state <= S0; end if;
                
            when S4 => -- "1101"
                if din = '1' then next_state <= S5; else next_state <= S0; end if;
                
            when S5 => -- "11011"
                if din = '0' then next_state <= S6; else next_state <= S2; end if;
                
            when S6 => -- "110110"
                if din = '1' then next_state <= S7; else next_state <= S0; end if;
                
            when S7 => -- "1101101"
                if din = '1' then next_state <= S8_MATCH; else next_state <= S0; end if;
                
            when S8_MATCH => -- "11011011" (Dete��o completa!)
                -- Aqui tratamos o Overlap cr�tico:
                if din = '0' then 
                    next_state <= S6; -- Se vier '0', a sequ�ncia acumulada "110110110" reaproveita os �ltimos 6 bits ("110110")
                else 
                    next_state <= S2; -- Se vier '1', a sequ�ncia "110110111" reaproveita apenas os �ltimos 2 bits ("11")
                end if;
                
            when others =>
                next_state <= S0;
        end case;
    end process;

end architecture;