library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity seq_detector_tb is
end entity;

architecture sim of seq_detector_tb is
    -- Sinais de interface
    signal clk    : std_logic := '0';
    signal rst    : std_logic := '0';
    signal din    : std_logic := '0';
    signal detect : std_logic;

    -- Per�odo do rel�gio (50 MHz)
    constant CLK_PERIOD : time := 20 ns;
    
    -- Registo de deslocamento interno para o testbench fazer a auto-verifica��o
    signal shift_reg : std_logic_vector(7 downto 0) := (others => '0');
    signal expected_detect : std_logic := '0';

begin

    -- Instancia��o da Unidade Sob Teste (UUT)
    uut: entity work.seq_detector
        port map (
            clk    => clk,
            rst    => rst,
            din    => din,
            detect => detect
        );

    -- Gerador de Rel�gio
    clk_process : process
    begin
        while true loop
            clk <= '0'; wait for CLK_PERIOD/2;
            clk <= '1'; wait for CLK_PERIOD/2;
        end loop;
    end process;

    -- Processo de Monitoriza��o e Auto-Verifica��o (S�ncrono)
    check_process : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                shift_reg <= (others => '0');
                expected_detect <= '0';
            else
                -- Atualiza o registo de deslocamento com o bit que ACABA de ser amostrado
                shift_reg <= shift_reg(6 downto 0) & din;
                
                -- L�gica de previs�o: se o registo atual (ap�s o shift) for igual ao padr�o,
                -- a FSM do tipo Moore deve ativar o 'detect' no PR�XIMO ciclo.
                if (shift_reg(6 downto 0) & din) = "11011011" then
                    expected_detect <= '1';
                else
                    expected_detect <= '0';
                end if;
            end if;
            
            -- Verifica��o por Asser��o (Valida o ciclo atual contra a previs�o do ciclo anterior)
            -- Como � Moore, h� 1 ciclo de lat�ncia, logo avaliamos o 'expected_detect' calculado no ciclo anterior
            if rst = '0' then
                assert (detect = expected_detect)
                    report "ERRO: Diverg�ncia detetada! Obtido=" & std_logic'image(detect) & 
                           " Esperado=" & std_logic'image(expected_detect)
                    severity failure;
            end if;
        end if;
    end process;

    -- Processo de Est�mulos
    stim_process : process
        -- Procedimento auxiliar para injetar um bit
        procedure send_bit(bit_val : std_logic) is
        begin
            din <= bit_val;
            wait for CLK_PERIOD;
        end procedure;
    begin
        -- 1. Aplicar Reset S�ncrono
        rst <= '1';
        wait for CLK_PERIOD * 2;
        rst <= '0';
        wait for CLK_PERIOD;

        -- 2. Injetar Padr�o Limpo (11011011) -> Deve detetar no fim
        send_bit('1'); send_bit('1'); send_bit('0'); send_bit('1');
        send_bit('1'); send_bit('0'); send_bit('1'); send_bit('1'); -- Termina aqui o 1� Match
        
        -- 3. Injetar bits para testar o OVERLAP com '0'
        -- O fim do padr�o anterior foi "...11011011". Se injetarmos '011011', 
        -- aproveitamos os primeiros bits "110110" devido ao overlap!
        send_bit('0'); send_bit('1'); send_bit('1'); send_bit('0'); 
        send_bit('1'); send_bit('1'); -- Deve gerar o 2� Match aqui por sobreposi��o

        -- 4. Injetar bits aleat�rios para quebrar a sequ�ncia
        send_bit('0'); send_bit('0'); send_bit('1'); send_bit('0');
        
        -- 5. Injetar bits para testar o OVERLAP com '1'
        -- Padr�o completo:
        send_bit('1'); send_bit('1'); send_bit('0'); send_bit('1');
        send_bit('1'); send_bit('0'); send_bit('1'); send_bit('1'); -- 3� Match
        -- Se injetarmos logo outro '1', a sequ�ncia fica "...110110111", recua para o estado S2 ("11").
        -- Se completarmos com "011011", deve dar match novamente.
        send_bit('1'); -- Volta ao S2
        send_bit('0'); send_bit('1'); send_bit('1'); send_bit('0'); 
        send_bit('1'); send_bit('1'); -- 4� Match por sobreposi��o de '1'

        -- Fim do teste com sucesso
        report "SUCESSO: Simulacao concluida sem falhas de assercao!";
        wait;
    end process;

end architecture;