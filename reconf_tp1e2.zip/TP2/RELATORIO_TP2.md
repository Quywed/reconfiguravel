# Relatório Técnico: Cifra de Fluxo com Keystream LFSR

**Cadeira:** Computação Reconfigurável  
**Instituição:** Universidade do Algarve - Instituto Superior de Engenharia (UAlg ISE)  
**Ano Letivo:** 2025/2026

**Realizado por:**
* Lucas Machadinho Martins - a79294 - a79294@ualg.pt

---

Este trabalho serve para criar e testar um sistema de cifra de fluxo síncrona que usa um gerador de chave pseudoaleatória. O circuito faz uma operação XOR entre os bits da chave e os bits dos dados de entrada para encriptar a informação. O projeto foi feito de forma estrutural para juntar um bloco de encriptação e um de decriptação no mesmo teste e ver se os dados originais são recuperados corretamente.

---

## 1. Organização e Função de Cada Ficheiro

Para o projeto ficar bem organizado e dividido por módulos, usei quatro ficheiros:

1. **`lfsr8.vhd`:**
   * É o gerador de bits pseudoaleatórios (a chave)
   * Atualiza o estado do registo a cada flanco de relógio e usa uma semente inicial para não começar a zeros.

2. **`stream_cipher.vhd`:**
   * É o ficheiro principal da cifra.
   * Chama o módulo `lfsr8` lá dentro (design estrutural) e faz o XOR com o bit de entrada `din`. A saída é registada, o que adiciona um ciclo de atraso.

3. **`stream_cipher_tb.vhd`:**
   * É o ficheiro de teste (testbench) auto-verificável.
   * Liga duas cifras em cadeia (uma para encriptar e outra para decriptar) com a mesma semente. Também atrasa o sinal original por dois ciclos para confirmar com um `assert` se a decriptação funcionou bem.

4. **`sim.do`:**
   * É o script de comandos para o ModelSim.
   * Cria a biblioteca de trabalho, compila os ficheiros VHDL na ordem certa, abre o simulador com os sinais organizados por cores e corre o teste sozinho.

---

## 2. Funcionamento do Algoritmo e Arquitetura

O gerador de chaves (LFSR) usa o polinómio $x^8 + x^6 + x^5 + x^4 + 1$. Isto significa que temos de ir buscar os bits das posições 7, 5, 4 e 3 para fazer a lógica do feedback:
```vhdl
feedback <= state(7) xor state(5) xor state(4) xor state(3);
```

O bit que vai servir de chave para a cifra é o bit mais à esquerda do registo ``( state(7) )``.  Como ligamos duas cifras seguidas e cada uma demora um ciclo de relógio a registar a saída, o dado decriptado no fim (``dec_out``) vai aparecer com dois ciclos de atraso em relação ao ``din`` original. Para o segundo bloco conseguir decriptar bem, o sinal ``dec_enable`` tem de ser ligado exatamente um ciclo de relógio depois do ``enable`` do primeiro bloco, mantendo as chaves alinhadas.  

---
## 3. Excertos do Código
### Atualização do LFSR (``lfsr8.vhd``)

Este bloco faz o deslocamento dos bits e mete o feedback na posição da direita quando o ``enable`` está a '1'. Se o reset for ativado, volta à semente inicial (``0xAE``):  

```vhdl
process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            state <= INIT;
        elsif enable = '1' then
            state <= state(6 downto 0) & feedback;
        end if;
    end if;
end process;
```

### Instanciação Estrutural da Cifra (``stream_cipher.vhd``)

Aqui ligamos o LFSR ao processo do XOR para criar a saída da cifra:  

```vhdl
lfsr_inst: entity work.lfsr8
    generic map (
        INIT => INIT_SEED
    )
    port map (
        clk       => clk,
        rst       => rst,
        enable    => enable,
        state_out => open,
        bit_out   => lfsr_bit
    );

process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            dout <= '0';
        elsif enable = '1' then
            dout <= din xor lfsr_bit;
        end if;
    end if;
end process;
```

### Verificação no Testbench (``stream_cipher_tb.vhd``)

O testbench guarda o histórico do ``din`` criando um atraso de dois ciclos para comparar com a saída final:  

```vhdl
process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            din_delayed_1 <= '0';
            din_delayed_2 <= '0';
        else
            din_delayed_1 <= din;
            din_delayed_2 <= din_delayed_1;
        end if;
    end if;
end process;

process(clk)
begin
    if rising_edge(clk) then
        if rst = '0' and dec_enable_delayed = '1' then
            assert (dec_out = din_delayed_2)
                report "ERRO: O dado decriptado nao e igual ao dado original atrasado!"
                severity failure;
        end if;
    end if;
end process;
```