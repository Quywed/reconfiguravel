library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity stream_cipher is
    generic (
        INIT_SEED : std_logic_vector(7 downto 0) := x"AE"
    );
    port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        enable  : in  std_logic;
        din     : in  std_logic;
        dout    : out std_logic;
        key_bit : out std_logic
    );
end entity;

architecture structural of stream_cipher is
    signal lfsr_bit : std_logic;
begin

    lfsr_inst: entity work.lfsr8
        generic map (
            INIT => INIT_SEED
        )
        port map (
            clk       => clk,
            rst       => rst,
            enable    => enable,
            state_out => open,
            bit_out   => lfsr_bit
        );

    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                dout <= '0';
            elsif enable = '1' then
                dout <= din xor lfsr_bit;
            end if;
        end if;
    end process;

    key_bit <= lfsr_bit;

end architecture;