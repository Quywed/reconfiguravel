library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity lfsr8 is
    generic (
        INIT : std_logic_vector(7 downto 0) := x"AE"
    );
    port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        enable    : in  std_logic;
        state_out : out std_logic_vector(7 downto 0);
        bit_out   : out std_logic
    );
end entity;

architecture rtl of lfsr8 is
    signal state : std_logic_vector(7 downto 0) := INIT;
    signal feedback : std_logic;
begin

    feedback <= state(7) xor state(5) xor state(4) xor state(3);

    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                state <= INIT;
            elsif enable = '1' then
                state <= state(6 downto 0) & feedback;
            end if;
        end if;
    end process;

    state_out <= state;
    bit_out   <= state(7);

end architecture;