library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity stream_cipher_tb is
end entity;

architecture sim of stream_cipher_tb is
    signal clk        : std_logic := '0';
    signal rst        : std_logic := '0';
    signal enable     : std_logic := '0';
    signal dec_enable : std_logic := '0';
    signal din        : std_logic := '0';
    
    signal enc_out    : std_logic;
    signal dec_out    : std_logic;
    signal keystream  : std_logic;
    signal ks_dec     : std_logic;

    constant CLK_PERIOD : time := 10 ns;
    
    signal din_delayed_1 : std_logic := '0';
    signal din_delayed_2 : std_logic := '0';
    signal dec_enable_delayed : std_logic := '0';
begin

    encoder: entity work.stream_cipher
        generic map ( INIT_SEED => x"AE" )
        port map (
            clk => clk, rst => rst, enable => enable,
            din => din, dout => enc_out, key_bit => keystream
        );

    decoder: entity work.stream_cipher
        generic map ( INIT_SEED => x"AE" )
        port map (
            clk => clk, rst => rst, enable => dec_enable,
            din => enc_out, dout => dec_out, key_bit => ks_dec
        );

    clk_process : process
    begin
        while true loop
            clk <= '0'; wait for CLK_PERIOD/2;
            clk <= '1'; wait for CLK_PERIOD/2;
        end loop;
    end process;

    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                din_delayed_1 <= '0';
                din_delayed_2 <= '0';
                dec_enable_delayed <= '0';
            else
                din_delayed_1 <= din;
                din_delayed_2 <= din_delayed_1;
                dec_enable_delayed <= dec_enable;
            end if;
        end if;
    end process;

    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '0' and dec_enable_delayed = '1' then
                assert (dec_out = din_delayed_2)
                    report "ERRO: Falha na decriptacao! Dado recuperado incorreto."
                    severity failure;
            end if;
        end if;
    end process;

    stim_process : process
    begin
        rst <= '1';
        wait for CLK_PERIOD * 2;
        rst <= '0';
        wait for CLK_PERIOD;

        enable <= '1';
        din <= '1'; wait for CLK_PERIOD;
        
        dec_enable <= '1';
        din <= '0'; wait for CLK_PERIOD;
        din <= '1'; wait for CLK_PERIOD;
        din <= '1'; wait for CLK_PERIOD;
        din <= '0'; wait for CLK_PERIOD;
        
        enable <= '0';
        dec_enable <= '0';
        wait for CLK_PERIOD * 2;
        
        enable <= '1';
        dec_enable <= '1';
        din <= '1'; wait for CLK_PERIOD;
        din <= '0'; wait for CLK_PERIOD;

        enable <= '0';
        wait for CLK_PERIOD;
        dec_enable <= '0';

        report "SUCESSO: Desafio de criptografia validado sem falhas!";
        wait;
    end process;

end architecture;