if [file exists work] { vdel -all -lib work }
vlib work

vcom -93 lfsr8.vhd
vcom -93 stream_cipher.vhd
vcom -93 stream_cipher_tb.vhd

vsim -voptargs="+acc" work.stream_cipher_tb

add wave -divider "Controlo Geral"
add wave -color "Yellow" /stream_cipher_tb/clk
add wave -color "Red"    /stream_cipher_tb/rst
add wave -color "Orange" /stream_cipher_tb/enable
add wave -color "Orange" /stream_cipher_tb/dec_enable

add wave -divider "Pipeline de Dados"
add wave -color "Cyan"   /stream_cipher_tb/din
add wave -color "Pink"   /stream_cipher_tb/enc_out
add wave -color "Green"  /stream_cipher_tb/dec_out

add wave -divider "Sincronismo de Keystreams"
add wave -color "White"  /stream_cipher_tb/keystream
add wave -color "White"  /stream_cipher_tb/ks_dec

run 140 ns
wave zoom full