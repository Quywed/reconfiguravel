library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_uart_8 is
end entity tb_uart_8;

architecture sim of tb_uart_8 is

    signal clk       : std_logic := '0';
    signal rst       : std_logic := '0';
    signal tx_start  : std_logic := '0';
    signal tx_data   : std_logic_vector(7 downto 0) := (others => '0');
    signal tx_busy   : std_logic;
    signal tx_line   : std_logic;
    signal rx_line   : std_logic;
    signal rx_data   : std_logic_vector(7 downto 0);
    signal rx_valid  : std_logic;
    signal crc_error : std_logic;
    signal inject_active : std_logic := '0';

    constant CLK_PERIOD : time := 10 ns;

begin

    uut: entity work.uart_8
        port map (
            clk       => clk,
            rst       => rst,
            tx_start  => tx_start,
            tx_data   => tx_data,
            tx_busy   => tx_busy,
            tx_line   => tx_line,
            rx_line   => rx_line,
            rx_data   => rx_data,
            rx_valid  => rx_valid,
            crc_error => crc_error
        );

    -- Geração do Clock (período de 10ns)
    clk_process : process
    begin
        clk <= '0'; wait for CLK_PERIOD/2;
        clk <= '1'; wait for CLK_PERIOD/2;
    end process;

    -- Canal com injeção de erro por XOR controlado
    rx_line <= tx_line xor inject_active;

    -- Sequência de Estímulos Estrita (Baseada na cronologia da Figura 4)
    stim_process: process
    begin
        -- Estado Inicial (0 ns)
        rst           <= '1';
        tx_start      <= '0';
        tx_data       <= "00000000";
        inject_active <= '0';
        
        -- Reset desce aos 45 ns
        wait for 45 ns;
        rst <= '0';
        
        ---------------------------------------------------------------------
        -- 1º Frame: Transmissão Limpa (Payload: 10100101) às 95 ns
        ---------------------------------------------------------------------
        wait for 50 ns; 
        tx_data  <= "10100101";
        tx_start <= '1';
        
        wait for 10 ns; -- Pulso completo até aos 105 ns
        tx_start <= '0';
        
        ---------------------------------------------------------------------
        -- 2º Frame: Com Injeção de Erro (Payload: 00111100) às 215 ns
        ---------------------------------------------------------------------
        wait for 110 ns; 
        tx_data  <= "00111100";
        tx_start <= '1';
        
        wait for 10 ns; -- Pulso completo até aos 225 ns
        tx_start <= '0';
        
        -- Ativação do erro cirurgicamente em cima do bit de CRC (310 ns a 320 ns)
        wait for 85 ns;
        inject_active <= '1';
        
        wait for 10 ns;
        inject_active <= '0';
        
        -- Mantém a simulação em IDLE até fechar o gráfico aos 450 ns
        wait for 130 ns;
        
        report "Simulacao concluida com sucesso! Verifique o alinhamento das Waveforms.";
        wait;
    end process;

end architecture sim;