# Relatório Técnico: Implementação de UART Simples com Bit CRC

**Cadeira:** Computação Reconfigurável 

**Instituição:** Universidade do Algarve - Instituto Superior de Engenharia (UAlg ISE) 

**Ano Letivo:** 2025/2026 

**Realizado por:**

* Lucas Machadinho Martins - a79294 - a79294@ualg.pt

Este trabalho prático consiste no desenvolvimento e teste de um bloco de comunicação série UART customizado para o processamento de payloads de 8 bits. O canal de comunicação opera de forma totalmente síncrona com base num modelo sem sobreamostragem (um ciclo de relógio por bit). Para além da transmissão de dados, o sistema inclui um mecanismo de deteção de erros baseado num bit de redundância cíclica (CRC) calculado via redução XOR. A verificação funcional é realizada através de um testbench auto-verificável com injeção programada de falhas, cujos resultados são validados face às formas de onda de referência do enunciado.

---

## 1. Organização e Função de Cada Ficheiro

Para cumprir os requisitos de entrega e garantir uma estrutura modular e de fácil manutenção, o projeto é composto por três ficheiros principais:

1. **`uart_8.vhd`:**
* Ficheiro de design principal que contém a descrição de hardware da UART.


* Implementa o transmissor (TX) e o recetor (RX) como processos concorrentes e independentes.


* Gere as transições de estados e o cálculo/validação em tempo real do bit de CRC.




2. **`tb_uart_8.vhd`:**
* Ficheiro de teste (testbench) auto-verificável baseado em asserções lógicas.


* Instancia a UART e estabelece uma ligação em loopback físico (`tx_line` conectada diretamente a `rx_line`).


* Controla o sinal auxiliar `inject_active` para corromper deliberadamente o bit de CRC no segundo frame e verificar a robustez do recetor.




3. **`sim.do`:**
* Script de automatização para o ModelSim.


* Cria a biblioteca de trabalho, compila os ficheiros VHDL na ordem correta, organiza e formata os sinais na janela *Wave* divididos por blocos funcionais e corre a simulação até aos 450 ns.





---

## 2. Funcionamento do Protocolo e Arquitetura

### 2.1 Formato Customizado do Frame UART

O protocolo de comunicação série desenvolvido utiliza uma linha em repouso alta (*idle-high*). Cada frame transmitido possui uma estrutura rígida composta por 11 bits:

* 
**Start Bit:** 1 bit lógico em '0' que sinaliza o início da transmissão.


* 
**Word Data:** 8 bits de payload, transmitidos obrigatoriamente a começar pelo bit menos significativo (LSB primeiro).


* 
**CRC Bit:** 1 bit calculado através do XOR sucessivo (redução XOR) de todos os 8 bits do payload.


* 
**Stop Bit:** 1 bit lógico em '1' que delimita o fim do frame.



```
+-----------+----+----+----+----+----+----+----+----+---------+----------+
| START (0) | D0 | D1 | D2 | D3 | D4 | D5 | D6 | D7 | CRC_XOR | STOP (1) |
+-----------+----+----+----+----+----+----+----+----+---------+----------+

```

### 2.2 Arquitetura das Máquinas de Estados (FSM)

#### Transmissor (TX FSM)

O transmissor permanece em repouso no estado `ST_TX_IDLE` com a linha `tx_line` em '1'. Quando o sinal `tx_start` recebe um pulso de um ciclo, o payload presente em `tx_data` é capturado, o bit de CRC é pré-calculado e o sinal `tx_busy` é ativado. A FSM percorre sequencialmente os estados:

* 
`ST_TX_START`: Emite o bit de arranque ('0').


* 
`ST_TX_DATA`: Desloca e emite os 8 bits de dados (LSB para MSB) utilizando um contador interno.


* 
`ST_TX_CRC`: Coloca o bit de CRC calculado na linha série.


* 
`ST_TX_STOP`: Transmite o bit de paragem ('1') e desativa o pino `tx_busy` antes de retornar ao estado de repouso.



#### Recetor (RX FSM)

O recetor monitoriza constantemente a linha de entrada em `ST_RX_IDLE`. Ao detetar uma transição para o nível lógico '0' (Start bit), inicializa os acumuladores e transita para o estado de amostragem:

* 
`ST_RX_DATA`: Amostra a linha síncronamente durante 8 ciclos de relógio, guardando os bits num registo de deslocamento e calculando o XOR corrente.


* 
`ST_RX_CRC`: Recebe o bit de CRC vindo da linha e compara-o com o resultado calculado localmente, ativando uma flag interna em caso de divergência.


* 
`ST_RX_STOP`: Independentemente de haver erro ou não, o recetor atualiza a saída `rx_data` com o byte reconstruído e pulsa o pino `rx_valid`. Se a flag de divergência de CRC tiver sido ativada, o pino `crc_error` é levantado em simultâneo por um ciclo de relógio.



### 2.3 Modelo de Temporização (Sem Sobreamostragem)

Ao contrário das UARTs comerciais que utilizam sobreamostragem (tipicamente 8x ou 16x) para alinhar a leitura ao centro do bit, este design adota um modelo simplificado e determinístico onde **cada bit ocupa exatamente um ciclo completo de relógio** ($1\text{ bit} = 1\text{ período de } clk$). Esta abordagem pressupõe um canal síncrono ideal, facilitando a validação direta em ambiente de simulação.

---

## 3. Excertos Importantes do Código

### 3.1 Instanciação e Loopback no Testbench (`tb_uart_8.vhd`)

O ambiente de teste estabelece a ligação direta entre o transmissor e o recetor e adiciona uma porta lógica XOR intermédia para permitir o controlo da injeção de falhas na linha série:

```vhdl
-- Instanciação da Unidade Sob Teste (UUT)
uut: entity work.uart_8
    port map (
        clk       => clk,
        rst       => rst,
        tx_start  => tx_start,
        tx_data   => tx_data,
        tx_busy   => tx_busy,
        tx_line   => tx_line,
        rx_line   => rx_line,
        rx_data   => rx_data,
        rx_valid  => rx_valid,
        crc_error => crc_error
    );

-- Canal com injeção de erro por XOR controlado
rx_line <= tx_line xor inject_active;

```

### 3.2 Lógica de Terminação de Frame e Erro Simultâneo (`uart_8.vhd`)

A FSM do recetor garante que os dados corrompidos chegam à saída e o pulso de validação é gerado mesmo em caso de falha de integridade, levantando o alarme correspondente:

```vhdl
when ST_RX_STOP =>
    -- COMPORTAMENTO FIGURA 4: Atualiza os dados e valida o fim do frame sempre
    rx_data  <= rx_shifter;
    rx_valid <= '1';
    
    -- Se houver falha de paridade ou stop bit incorreto, levanta o erro em paralelo
    if crc_mismatch = '1' or rx_line = '0' then
        crc_error <= '1';
    end if;
    rx_state <= ST_RX_IDLE;

```

---

## 4. Análise das Waveforms (Simulação no ModelSim)

A análise da temporização obtida através da execução do script reproduz fielmente as especificações da Figura 4 do enunciado do problema.

### A. Fase de Reset e Estado Inicial (0 ns a 95 ns)

Durante os primeiros ciclos de relógio, o sinal `rst` encontra-se ativo em nível alto, forçando ambas as FSMs para o estado `IDLE`.

**Comportamento:** As linhas `tx_line` e `rx_line` mantêm-se em '1' (*idle-high*). Os pinos de controlo `tx_busy`, `rx_valid` e `crc_error` encontram-se em '0'. O barramento de dados `tx_data` inicia a zeros.

![Alt text](pics_readme/pic_a.png)


### B. Primeira Transmissão: Frame Limpo (95 ns a 215 ns)

Aos 95 ns, o barramento `tx_data` é carregado com o valor `10100101` e o sinal `tx_start` efetua um pulso limpo com a duração exata de um ciclo de clock (10 ns).


**Comportamento:** O sinal `tx_busy` sobe imediatamente para '1'. A linha `tx_line` cai para '0' (Start bit) no ciclo seguinte e transmite ordenadamente os dados bit a bit (LSB primeiro: '1', '0', '1', '0', '0', '1', '0', '1'). O bit de CRC gerado para este padrão é '0' ($1 \oplus 0 \oplus 1 \oplus 0 \oplus 0 \oplus 1 \oplus 0 \oplus 1 = 0$). À passagem dos 210 ns, o recetor conclui a leitura do Stop bit, atualiza o `rx_data` para `10100101` e pulsa o `rx_valid` a '1'. O sinal `crc_error` permanece a zeros.

![Alt text](pics_readme/pic_b.png)



### C. Segunda Transmissão e Injeção de Falha (215 ns a 340 ns)

Às 215 ns, inicia-se o segundo envio com o payload `00111100`. O sinal `tx_busy` volta a subir e o frame série desenvolve-se normalmente. O bit de CRC correto para este payload deveria ser '0' ($0 \oplus 0 \oplus 1 \oplus 1 \oplus 1 \oplus 1 \oplus 0 \oplus 0 = 0$).

**Comportamento:** Entre os 310 ns e 320 ns (período correspondente ao envio do bit CRC), o testbench força o sinal `inject_active` para '1'. Isto causa a inversão instantânea do bit na linha, fazendo com que o `rx_line` leia um nível lógico '1' em vez de '0'.

![Alt text](pics_readme/pic_c.png)


### D. Sinalização de Validade e Erro Simultâneos (330 ns a 340 ns)

Ao atingir a janela do Stop bit do segundo frame (330 ns), a FSM do recetor processa o encerramento do bloco de receção.

**Comportamento:** Como o recetor calculou internamente '0' mas leu '1' vindo da linha corrompida, a incompatibilidade é detetada. Em conformidade com a Figura 4, o `rx_data` assume o valor do payload (`00111100`), o sinal `rx_valid` gera o seu pulso de término, e em simultâneo, o sinal `crc_error` sobe para '1' durante um ciclo de clock, acusando a violação de integridade.

![Alt text](pics_readme/pic_d.png)


---

## 5. Como Executar o Projeto no ModelSim

1. Copie os três ficheiros fornecidos (`uart_8.vhd`, `tb_uart_8.vhd` e `sim.do`) para a sua pasta local de trabalho.
2. Inicie o ambiente de simulação **ModelSim Intel FPGA**.
3. Aceda ao menu superior e clique em **File -> Change Directory...**, selecionando a pasta onde armazenou os ficheiros.
4. Consolide a execução digitando o seguinte comando na linha de comandos **Transcript**:

```tcl
do sim.do

```

5. O script irá inicializar as bibliotecas, compilar o código fonte, configurar a disposição e cores dos sinais e abrir a janela de visualização gráfica `Wave` com o zoom perfeitamente ajustado aos 450 ns da simulação.