library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity uart_8 is
    port (
        clk       : in  std_logic;                    -- 1 ciclo = 1 bit
        rst       : in  std_logic;                    -- Reset síncrono ativo em alto
        tx_start  : in  std_logic;                    -- Pulso para iniciar TX
        tx_data   : in  std_logic_vector(7 downto 0); -- Payload de entrada
        tx_busy   : out std_logic;                    -- High while TX is emitting a frame
        tx_line   : out std_logic;                    -- Linha de saída (idle-high)
        rx_line   : in  std_logic;                    -- Linha de entrada (idle-high)
        rx_data   : out std_logic_vector(7 downto 0); -- Payload recebido
        rx_valid  : out std_logic;                    -- Pulsa no fim de qualquer frame terminado
        crc_error : out std_logic                     -- Pulsa em simultâneo se houver erro de CRC
    );
end entity uart_8;

architecture behavioral of uart_8 is

    type tx_state_type is (ST_TX_IDLE, ST_TX_START, ST_TX_DATA, ST_TX_CRC, ST_TX_STOP);
    signal tx_state    : tx_state_type := ST_TX_IDLE;
    signal tx_shifter  : std_logic_vector(7 downto 0) := (others => '0');
    signal tx_crc_reg  : std_logic := '0';
    signal tx_bit_cnt  : integer range 0 to 7 := 0;

    type rx_state_type is (ST_RX_IDLE, ST_RX_DATA, ST_RX_CRC, ST_RX_STOP);
    signal rx_state     : rx_state_type := ST_RX_IDLE;
    signal rx_shifter   : std_logic_vector(7 downto 0) := (others => '0');
    signal rx_crc_calc  : std_logic := '0';
    signal rx_bit_cnt   : integer range 0 to 7 := 0;
    signal crc_mismatch : std_logic := '0';

begin

    -------------------------------------------------------------------------
    -- Transmissor (Processo TX separado)
    -------------------------------------------------------------------------
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                tx_state   <= ST_TX_IDLE;
                tx_line    <= '1';
                tx_busy    <= '0';
                tx_shifter <= (others => '0');
                tx_crc_reg <= '0';
                tx_bit_cnt <= 0;
            else
                case tx_state is
                    when ST_TX_IDLE =>
                        tx_line <= '1';
                        tx_busy <= '0';
                        if tx_start = '1' then
                            -- Captura e regista os dados no ciclo de start (tx_busy continua a '0')
                            tx_shifter <= tx_data;
                            tx_crc_reg <= tx_data(0) xor tx_data(1) xor tx_data(2) xor tx_data(3) xor 
                                          tx_data(4) xor tx_data(5) xor tx_data(6) xor tx_data(7);
                            tx_state   <= ST_TX_START;
                        end if;

                    when ST_TX_START =>
                        -- INÍCIO DO FRAME: tx_line vai para '0' e tx_busy vai para '1' em simultâneo
                        tx_line    <= '0'; -- Start bit na linha
                        tx_busy    <= '1';
                        tx_bit_cnt <= 0;
                        tx_state   <= ST_TX_DATA;

                    when ST_TX_DATA =>
                        tx_busy <= '1';
                        tx_line <= tx_shifter(0); -- Desloca os dados (LSB primeiro)
                        if tx_bit_cnt = 7 then
                            tx_state <= ST_TX_CRC;
                        else
                            tx_shifter <= '0' & tx_shifter(7 downto 1);
                            tx_bit_cnt <= tx_bit_cnt + 1;
                        end if;

                    when ST_TX_CRC =>
                        tx_busy  <= '1';
                        tx_line  <= tx_crc_reg; -- Bit de CRC na linha
                        tx_state <= ST_TX_STOP;

                    when ST_TX_STOP =>
                        tx_line  <= '1'; -- Stop bit (logic 1)
                        tx_busy  <= '1'; -- Continua em alto durante a emissão do stop bit
                        tx_state <= ST_TX_IDLE; -- No próximo ciclo volta a IDLE (tx_busy cai para '0')
                end case;
            end if;
        end if;
    end process;

    -------------------------------------------------------------------------
    -- Recetor (Processo RX separado)
    -------------------------------------------------------------------------
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                rx_state     <= ST_RX_IDLE;
                rx_data      <= (others => '0');
                rx_valid     <= '0';
                crc_error    <= '0';
                rx_shifter   <= (others => '0');
                rx_crc_calc  <= '0';
                rx_bit_cnt   <= 0;
                crc_mismatch <= '0';
            else
                rx_valid  <= '0';
                crc_error <= '0';

                case rx_state is
                    when ST_RX_IDLE =>
                        if rx_line = '0' then
                            rx_crc_calc  <= '0';
                            rx_bit_cnt   <= 0;
                            crc_mismatch <= '0';
                            rx_state     <= ST_RX_DATA;
                        end if;

                    when ST_RX_DATA =>
                        rx_shifter(rx_bit_cnt) <= rx_line;
                        rx_crc_calc            <= rx_crc_calc xor rx_line;
                        if rx_bit_cnt = 7 then
                            rx_state <= ST_RX_CRC;
                        else
                            rx_bit_cnt <= rx_bit_cnt + 1;
                        end if;

                    when ST_RX_CRC =>
                        if rx_line /= rx_crc_calc then
                            crc_mismatch <= '1';
                        else
                            crc_mismatch <= '0';
                        end if;
                        rx_state <= ST_RX_STOP;

                    when ST_RX_STOP =>
                        rx_data  <= rx_shifter;
                        rx_valid <= '1';
                        if crc_mismatch = '1' or rx_line = '0' then
                            crc_error <= '1';
                        end if;
                        rx_state <= ST_RX_IDLE;
                end case;
            end if;
        end if;
    end process;

end architecture behavioral;