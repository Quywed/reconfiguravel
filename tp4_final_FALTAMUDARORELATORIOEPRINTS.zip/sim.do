vlib work
vmap work work

vcom -work work uart_8.vhd
vcom -work work tb_uart_8.vhd

vsim -voptargs="+acc" work.tb_uart_8

add wave -divider "Sinais Globais"
add wave -noupdate -format Logic /tb_uart_8/clk
add wave -noupdate -format Logic /tb_uart_8/rst

add wave -divider "Transmissor (TX)"
add wave -noupdate -format Logic /tb_uart_8/tx_start
add wave -noupdate -format Literal -radix binary /tb_uart_8/tx_data
add wave -noupdate -format Logic /tb_uart_8/tx_busy
add wave -noupdate -format Logic /tb_uart_8/tx_line

add wave -divider "Canal com Falha"
add wave -noupdate -format Logic /tb_uart_8/rx_line
add wave -noupdate -format Literal -radix binary /tb_uart_8/rx_data
add wave -noupdate -format Logic /tb_uart_8/rx_valid
add wave -noupdate -format Logic /tb_uart_8/crc_error
add wave -noupdate -format Logic /tb_uart_8/inject_active

add wave -divider "Recetor (RX)"

configure wave -namecolwidth 180
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1

run 450 ns
wave zoom full